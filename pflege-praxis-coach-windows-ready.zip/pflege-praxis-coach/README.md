# Pflege Praxiscoach — Ready-to-Build (Windows)

**Ersteller:** Roman Woweries

Dieses ZIP enthält ein lauffähiges Projekt‑Skeleton (Expo + Electron). Es enthält Quellcode und Build‑Skripte — **kein vorgefertigtes .exe**.

## Schnellstart
1. Node.js v18+ installieren
2. In dieses Verzeichnis wechseln:
   ```bash
   cd pflege-praxis-coach
   npm install
   ```
3. Für Entwicklung:
   ```bash
   npm run start
   ```
4. Electron (Entwicklung):
   ```bash
   npm run electron:start
   ```
5. Produktion (EXE erzeugen):
   - Erst Web‑Build:
     ```bash
     npm run build:web
     ```
   - Dann EXE bauen:
     ```bash
     npm run electron:build
     ```

## Hinweise
- electron:build verwendet electron-builder. Für Signatur/Publishing sind zusätzliche Schritte erforderlich.
- Ich kann optional GitHub Actions Workflow hinzufügen, der auf Push automatisch eine Windows‑EXE baut und als Release‑Artefakt bereitstellt.
