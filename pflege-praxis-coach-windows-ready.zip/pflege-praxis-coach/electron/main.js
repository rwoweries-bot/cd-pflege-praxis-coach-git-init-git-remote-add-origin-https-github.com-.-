const { app, BrowserWindow } = require('electron');
const path = require('path');

function createWindow() {
  const win = new BrowserWindow({
    width: 1200,
    height: 800,
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true
    }
  });

  const devUrl = 'http://localhost:19006';
  if (process.env.ELECTRON_DEV === 'true') {
    win.loadURL(devUrl);
  } else {
    win.loadFile(path.join(__dirname, '..', 'web-build', 'index.html'));
  }
}

app.whenReady().then(createWindow);

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});
