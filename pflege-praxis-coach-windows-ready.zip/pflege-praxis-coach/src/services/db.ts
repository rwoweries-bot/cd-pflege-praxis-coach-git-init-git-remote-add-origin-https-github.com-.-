import * as SQLite from 'expo-sqlite';
const db = SQLite.openDatabase('pflegedb.db');

export function initDb() {
  db.transaction(tx => {
    tx.executeSql(
      `CREATE TABLE IF NOT EXISTS students (id TEXT PRIMARY KEY, name TEXT, level TEXT, ward TEXT, mentor TEXT);`
    );
    tx.executeSql(
      `CREATE TABLE IF NOT EXISTS rotations (id TEXT PRIMARY KEY, date TEXT, shift TEXT, studentId TEXT);`
    );
    tx.executeSql(
      `CREATE TABLE IF NOT EXISTS tasks (id TEXT PRIMARY KEY, title TEXT, studentId TEXT, due TEXT, status TEXT);`
    );
  });
}

export default db;
