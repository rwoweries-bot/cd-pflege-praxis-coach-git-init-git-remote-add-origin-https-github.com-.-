import React from 'react';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import Dashboard from '../screens/Dashboard';
import Schedule from '../screens/Schedule';
import Students from '../screens/Students';
import StudentDetail from '../screens/StudentDetail';
import Tasks from '../screens/Tasks';

const Stack = createNativeStackNavigator();

export default function StackNav() {
  return (
    <Stack.Navigator initialRouteName="Dashboard">
      <Stack.Screen name="Dashboard" component={Dashboard} />
      <Stack.Screen name="Einsatzplanung" component={Schedule} />
      <Stack.Screen name="Schüler" component={Students} />
      <Stack.Screen name="SchülerDetail" component={StudentDetail} />
      <Stack.Screen name="Aufgaben" component={Tasks} />
    </Stack.Navigator>
  );
}
