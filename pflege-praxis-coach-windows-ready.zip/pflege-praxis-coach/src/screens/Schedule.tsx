import React from 'react';
import { View, Text } from 'react-native';

export default function Schedule() {
  return (
    <View style={{flex:1,padding:16}}>
      <Text style={{fontSize:20,fontWeight:'600'}}>Einsatzplanung</Text>
      <Text style={{marginTop:8}}>Hier kommt die Kalenderansicht / Liste von Diensten.</Text>
    </View>
  );
}
