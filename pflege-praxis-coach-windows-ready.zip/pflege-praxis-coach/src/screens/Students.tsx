import React from 'react';
import { View, Text, FlatList, TouchableOpacity } from 'react-native';

const MOCK = [
  {id:'s1',name:'Anna Müller',level:'2. Jahr',ward:'Innere'},
  {id:'s2',name:'Tim Becker',level:'1. Jahr',ward:'Chirurgie'},
];

export default function Students({ navigation }: any) {
  return (
    <View style={{flex:1,padding:16}}>
      <Text style={{fontSize:20,fontWeight:'600'}}>Schüler:innen</Text>
      <FlatList
        data={MOCK}
        keyExtractor={i=>i.id}
        renderItem={({item}) => (
          <TouchableOpacity onPress={() => navigation.navigate('SchülerDetail', { id: item.id })} style={{padding:12,borderBottomWidth:1}}>
            <Text style={{fontWeight:'600'}}>{item.name}</Text>
            <Text>{item.level} • {item.ward}</Text>
          </TouchableOpacity>
        )}
      />
    </View>
  );
}
