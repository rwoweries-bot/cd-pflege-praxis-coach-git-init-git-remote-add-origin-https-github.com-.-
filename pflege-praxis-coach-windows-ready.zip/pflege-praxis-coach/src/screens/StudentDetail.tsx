import React from 'react';
import { View, Text } from 'react-native';

export default function StudentDetail({ route }: any) {
  const { id } = route.params || {};
  return (
    <View style={{flex:1,padding:16}}>
      <Text style={{fontSize:20,fontWeight:'600'}}>Schüler:in — {id}</Text>
      <Text style={{marginTop:8}}>Profil, Lernziele, Beurteilungen.</Text>
    </View>
  );
}
