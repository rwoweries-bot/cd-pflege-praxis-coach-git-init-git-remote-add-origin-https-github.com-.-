import React from 'react';
import { View, Text, Button } from 'react-native';

export default function Dashboard({ navigation }: any) {
  return (
    <View style={{flex:1,padding:16}}>
      <Text style={{fontSize:24,fontWeight:'700'}}>Pflege Praxiscoach</Text>
      <Text style={{marginTop:8}}>Dashboard — Übersicht zu Einsätzen und Schülern</Text>

      <View style={{marginTop:20}}>
        <Button title="Einsatzplanung" onPress={() => navigation.navigate('Einsatzplanung')} />
      </View>
      <View style={{marginTop:8}}>
        <Button title="Schüler" onPress={() => navigation.navigate('Schüler')} />
      </View>
      <View style={{marginTop:8}}>
        <Button title="Aufgaben" onPress={() => navigation.navigate('Aufgaben')} />
      </View>
    </View>
  );
}
