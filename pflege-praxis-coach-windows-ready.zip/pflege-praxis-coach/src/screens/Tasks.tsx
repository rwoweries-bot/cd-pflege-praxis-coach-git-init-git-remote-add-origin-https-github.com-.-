import React from 'react';
import { View, Text } from 'react-native';

export default function Tasks() {
  return (
    <View style={{flex:1,padding:16}}>
      <Text style={{fontSize:20,fontWeight:'600'}}>Aufgaben & Lernziele</Text>
      <Text style={{marginTop:8}}>Board mit offenen / in Arbeit / erledigt.</Text>
    </View>
  );
}
